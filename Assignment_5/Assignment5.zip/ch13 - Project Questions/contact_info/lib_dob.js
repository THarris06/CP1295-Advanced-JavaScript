"use strict";

export default class Dob extends Date {
    constructor(date) {
        super(date);
    }
}